﻿namespace MedicationDomain.Entities
{
	public interface IPatient
	{
	}
}