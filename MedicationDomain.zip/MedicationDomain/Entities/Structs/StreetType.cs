﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MedicationDomain.Entities.Enums
{
	public enum StreetType
	{

		Avenue,
		Boulevard, 
		Causeway,
		Circle,
		CountyRoad,
		Highway,
		Court, 
		Drive, 
		Lane, 
		Loop,
		Park,
		Parkway,
		Street, 
		Way, 

	}
}
